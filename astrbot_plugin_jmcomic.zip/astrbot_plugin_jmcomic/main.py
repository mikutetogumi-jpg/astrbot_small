import asyncio
import os
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register
from astrbot.api import logger
from astrbot.api.message_components import Plain, Image
import astrbot.api.message_components as Comp
from astrbot.core.platform.sources.aiocqhttp.aiocqhttp_message_event import AiocqhttpMessageEvent

from .jmcomic_utils import get_helper


@register("astrbot_plugin_jmcomic", "YourName", "JMComic 漫画助手", "3.3.4")
class JMComicPlugin(Star):
    """
    指令：
    - /jm [ID]         ：查询漫画详情
    - /jmsearch [关键词]：搜索漫画（第1页）
    - /p [页码]         ：翻页（自动撤回上一条）
    - /jmrandom         ：随机推荐
    - /jmdl [ID]        ：下载漫画，压缩加密发送
    """

    def __init__(self, context: Context):
        super().__init__(context)
        self.config = {}
        self.helper = None
        self._search_state = {}   # user_id -> {"keyword": str, "last_msg_id": str}

    async def _load_config(self):
        try:
            self.config = self.context.get_config() or {}
            self.config.setdefault("proxy", "")
            self.config.setdefault("download_dir", "./downloads/jmcomic")
            self.config.setdefault("random_page_max", 30)
            self.config.setdefault("enable_zip", True)

            loop = asyncio.get_event_loop()
            self.helper = await loop.run_in_executor(None, get_helper, self.config)
        except Exception as e:
            logger.error(f"加载配置失败: {e}")

    # ---------- 撤回任务 ----------
    async def _retract_task(self, event: AiocqhttpMessageEvent, message_id: int):
        await asyncio.sleep(0.5)
        try:
            client = event.bot
            await client.api.call_action("delete_msg", message_id=message_id)
            logger.info(f"[撤回] 成功撤回消息 {message_id}")
        except Exception as e:
            logger.error(f"[撤回] 撤回消息 {message_id} 失败: {e}")

    # ---------- 发送并记录 ----------
    async def _send_and_record(
        self, event: AiocqhttpMessageEvent, text: str, user_id: str, keyword: str, should_retract: bool = True
    ):
        client = event.bot
        group_id = event.get_group_id()
        message_content = [{'type': 'text', 'data': {'text': text}}]

        try:
            if group_id:
                sent_info = await client.send_group_msg(
                    group_id=int(group_id), message=message_content
                )
            else:
                sent_info = await client.send_private_msg(
                    user_id=int(event.get_sender_id()), message=message_content
                )

            if sent_info and isinstance(sent_info, dict) and sent_info.get("message_id"):
                msg_id = sent_info["message_id"]
                self._search_state[user_id] = {
                    "keyword": keyword,
                    "last_msg_id": msg_id
                }
                logger.debug(f"[状态] 已记录消息ID: {msg_id} for user {user_id}")
                return msg_id
            else:
                logger.warning(f"无法获取 message_id，发送响应: {sent_info}")
                return None
        except Exception as e:
            logger.error(f"OneBot 发送消息失败: {e}", exc_info=True)
            return None

    # ---------- 撤回上一条 ----------
    async def _retract_last_message(self, event: AstrMessageEvent, user_id: str):
        if not isinstance(event, AiocqhttpMessageEvent):
            return
        if not event.message_obj.group_id:
            return

        state = self._search_state.get(user_id, {})
        last_msg_id = state.get("last_msg_id")
        if last_msg_id:
            asyncio.create_task(self._retract_task(event, last_msg_id))

    # ---------- 查询 ----------
    @filter.command("jm")
    async def query_album(self, event: AstrMessageEvent):
        await self._load_config()
        if not self.helper or not self.helper.client:
            yield event.plain_result("❌ 客户端未初始化")
            return

        parts = event.message_str.strip().split()
        if len(parts) < 2:
            yield event.plain_result("❌ 用法：/jm [漫画ID]")
            return

        album_id = parts[1].strip()
        if not album_id.isdigit():
            yield event.plain_result("❌ 漫画ID必须为数字")
            return

        yield event.plain_result(f"🔍 正在查询漫画 ID: {album_id} ...")

        loop = asyncio.get_event_loop()
        album_info = await loop.run_in_executor(None, self.helper.get_album_detail, album_id)

        if not album_info:
            yield event.plain_result(f"❌ 未找到漫画 ID: {album_id}")
            return

        tags_str = ", ".join(album_info.get("tags", [])) or "无"
        text_msg = (
            f"📚 **{album_info['name']}**\n"
            f"🆔 ID：{album_info['id']}\n"
            f"✍️ 作者：{album_info['author']}\n"
            f"📄 页数：{album_info['page_count']}\n"
            f"👍 点赞：{album_info['likes']}  👁️ 浏览：{album_info['views']}\n"
            f"🏷️ 标签：{tags_str}\n"
            f"📖 简介：{album_info.get('description', '暂无')[:150]}..."
        )

        if album_info.get("cover_url"):
            yield event.chain_result([Plain(text_msg), Image.fromURL(album_info["cover_url"])])
        else:
            yield event.plain_result(text_msg)

    # ---------- 搜索（第1页）----------
    @filter.command("jmsearch")
    async def search_album(self, event: AstrMessageEvent):
        await self._load_config()
        if not self.helper or not self.helper.client:
            yield event.plain_result("❌ 客户端未初始化")
            return

        parts = event.message_str.strip().split()
        if len(parts) < 2:
            yield event.plain_result("❌ 用法：/jmsearch 关键词")
            return

        keyword = " ".join(parts[1:])
        user_id = event.get_sender_id()

        await self._retract_last_message(event, user_id)

        yield event.plain_result(f"🔍 正在搜索：{keyword} ...")

        loop = asyncio.get_event_loop()
        albums = await loop.run_in_executor(None, self.helper.search_albums, keyword, 1)

        if not albums:
            yield event.plain_result(f"❌ 未找到与 '{keyword}' 相关的漫画")
            return

        result_text = f"🔎 搜索 '{keyword}' 结果（前{len(albums)}条）：\n\n"
        for album in albums:
            result_text += f"📚 {album['name']}  |  🆔 {album['id']}  |  ✍️ {album['author']}\n"
        result_text += f"\n💡 发送 /p [页码] 可翻页（例如 /p 2）"

        if isinstance(event, AiocqhttpMessageEvent):
            await self._send_and_record(event, result_text, user_id, keyword, should_retract=False)
        else:
            yield event.plain_result(result_text)

    # ---------- 翻页 ----------
    @filter.command("p")
    async def page_jump(self, event: AstrMessageEvent):
        await self._load_config()
        if not self.helper or not self.helper.client:
            yield event.plain_result("❌ 客户端未初始化")
            return

        user_id = event.get_sender_id()
        state = self._search_state.get(user_id)
        if not state or not state.get("keyword"):
            yield event.plain_result("❌ 尚未进行过搜索，请先使用 /jmsearch 关键词")
            return

        keyword = state["keyword"]

        parts = event.message_str.strip().split()
        if len(parts) < 2 or not parts[1].isdigit():
            yield event.plain_result("❌ 用法：/p [页码]")
            return

        page = int(parts[1])
        if page < 1:
            page = 1

        await self._retract_last_message(event, user_id)

        yield event.plain_result(f"🔍 正在搜索：{keyword} (第 {page} 页) ...")

        loop = asyncio.get_event_loop()
        albums = await loop.run_in_executor(None, self.helper.search_albums, keyword, page)

        if not albums:
            yield event.plain_result("📭 未搜索到更多漫画")
            return

        result_text = f"🔎 搜索 '{keyword}' 结果 (第 {page} 页)：\n\n"
        for album in albums:
            result_text += f"📚 {album['name']}  |  🆔 {album['id']}  |  ✍️ {album['author']}\n"
        result_text += f"\n💡 发送 /p [页码] 可继续翻页"

        if isinstance(event, AiocqhttpMessageEvent):
            await self._send_and_record(event, result_text, user_id, keyword, should_retract=False)
        else:
            yield event.plain_result(result_text)

    # ---------- 随机 ----------
    @filter.command("jmrandom")
    async def random_album(self, event: AstrMessageEvent):
        await self._load_config()
        if not self.helper or not self.helper.client:
            yield event.plain_result("❌ 客户端未初始化")
            return

        yield event.plain_result("🎲 正在随机推荐 ...")
        max_page = self.config.get("random_page_max", 30)
        loop = asyncio.get_event_loop()
        album_info = await loop.run_in_executor(None, self.helper.get_random_album, max_page)

        if not album_info:
            yield event.plain_result("❌ 随机推荐失败")
            return

        tags_str = ", ".join(album_info.get("tags", [])) or "无"
        text_msg = (
            f"🎲 **随机推荐**\n"
            f"📚 {album_info['name']}\n"
            f"🆔 {album_info['id']}  |  ✍️ {album_info['author']}\n"
            f"👍 {album_info['likes']}  |  👁️ {album_info['views']}\n"
            f"🏷️ {tags_str}"
        )
        if album_info.get("cover_url"):
            yield event.chain_result([Plain(text_msg), Image.fromURL(album_info["cover_url"])])
        else:
            yield event.plain_result(text_msg)

    # ---------- 下载 ----------
    @filter.command("jmdl")
    async def download_album_cmd(self, event: AstrMessageEvent):
        await self._load_config()
        if not self.helper or not self.helper.client:
            yield event.plain_result("❌ 客户端未初始化")
            return

        parts = event.message_str.strip().split()
        if len(parts) < 2:
            yield event.plain_result("❌ 用法：/jmdl [漫画ID]")
            return

        album_id = parts[1].strip()
        if not album_id.isdigit():
            yield event.plain_result("❌ 漫画ID必须为数字")
            return

        loop = asyncio.get_event_loop()
        info = await loop.run_in_executor(None, self.helper.get_album_detail, album_id)
        name = info['name'] if info else album_id

        yield event.plain_result(f"⬇️ 开始下载漫画《{name}》(ID: {album_id})，请稍候...")

        enable_zip = self.config.get("enable_zip", True)

        success, password, result_path = await loop.run_in_executor(
            None, self.helper.download_album, album_id, enable_zip
        )

        if success:
            if enable_zip and password:
                chain = [
                    Comp.File(file=result_path, name=f"{album_id}.zip"),
                    Comp.Plain(f"✅ 《{name}》压缩包已下载！\n🔐 解压密码：{password}")
                ]
            else:
                chain = [Comp.Plain(f"✅ 下载完成！\n📁 保存路径：{result_path}")]
            yield event.chain_result(chain)
        else:
            yield event.plain_result("❌ 下载失败，请检查日志或稍后重试")

    async def terminate(self):
        logger.info("JMComic 插件已卸载")