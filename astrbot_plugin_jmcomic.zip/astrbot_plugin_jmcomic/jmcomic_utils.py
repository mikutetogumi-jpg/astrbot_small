import random
import re
import secrets
import string
import os
import jmcomic
import pyzipper
from typing import Optional, Dict, List, Any, Tuple
from astrbot.api import logger

try:
    from jmcomic import JmMagicConstants
except ImportError:
    class JmMagicConstants:
        ORDER_BY_LATEST = 'mr'
        TIME_ALL = 'a'
        CATEGORY_ALL = '0'


class JMComicHelper:
    """基于官方 jmcomic 库的稳定封装，支持下载后压缩加密，随机推荐已修复"""

    def __init__(self, proxy: str = "", download_dir: str = "./downloads/jmcomic"):
        self.proxy = proxy
        self.download_dir = download_dir

        option_dict = {
            "log": True,
            "client": {
                "impl": "api",
                "postman": {
                    "type": "cffi",
                    "meta_data": {
                        "impersonate": "chrome110",
                        "headers": {"User-Agent": "Mozilla/5.0"}
                    }
                },
                "retry_times": 5
            },
            "download": {
                "cache": True,
                "image": {"decode": True, "suffix": None},
                "threading": {"batch_count": 8},
            },
            "dir_rule": {"rule": "Bd_Aid", "base_dir": self.download_dir}
        }

        if self.proxy:
            option_dict["client"]["postman"]["meta_data"]["proxies"] = {
                "http": self.proxy, "https": self.proxy
            }
            logger.info(f"已配置代理: {self.proxy}")
        else:
            logger.info("未配置代理，将依赖 jmcomic 库自动获取最新域名")

        import json
        try:
            self.option = jmcomic.create_option_by_str(json.dumps(option_dict))
            self.client = self.option.build_jm_client()
            logger.info(f"JMComic 客户端初始化成功，下载目录: {self.download_dir}")
        except Exception as e:
            logger.error(f"JMComic 客户端初始化失败: {e}")
            self.client = None

    def get_album_detail(self, album_id: str) -> Optional[Dict[str, Any]]:
        if not self.client:
            return None
        try:
            album = self.client.get_album_detail(album_id)
            return self._format_album_detail(album)
        except Exception as e:
            logger.error(f"获取漫画 {album_id} 详情失败: {e}")
            return None

    def search_albums(self, keyword: str, page: int = 1) -> List[Dict[str, Any]]:
        if not self.client:
            return []
        try:
            search_result = self.client.search_site(keyword, page=page)
            albums = []
            if search_result and hasattr(search_result, 'content'):
                for item in search_result.content[:5]:
                    album_id = None
                    item_str = str(item)
                    match = re.search(r"'id'[:\s]*['\"]?(\d+)['\"]?", item_str)
                    if match:
                        album_id = match.group(1)
                    if not album_id:
                        if isinstance(item, dict):
                            album_id = item.get('id') or item.get('album_id') or item.get('aid')
                        else:
                            album_id = getattr(item, 'id', None) or getattr(item, 'album_id', None) or getattr(item, 'aid', None)
                    if not album_id:
                        continue
                    detail = self.get_album_detail(str(album_id))
                    if detail:
                        albums.append({
                            "id": str(album_id),
                            "name": detail.get('name', '未知'),
                            "author": detail.get('author', '未知'),
                            "cover_url": detail.get('cover_url')
                        })
            return albums
        except Exception as e:
            logger.error(f"搜索漫画 '{keyword}' 失败: {e}")
            return []

    def get_random_album(self, max_page: int = 30) -> Optional[Dict[str, Any]]:
        """随机获取一个漫画：通过热门关键词搜索，使用增强型ID提取（已修复元组错误）"""
        if not self.client:
            return None
        try:
            hot_keywords = [
                "原神", "火影", "海贼", "一拳", "咒术", "鬼灭", "间谍", "巨人", "龙珠", "死神",
                "无码", "汉化", "同人", "全彩"
            ]
            keyword = random.choice(hot_keywords)
            page = random.randint(1, 5)

            search_result = self.client.search_site(keyword, page=page)
            if not search_result or not hasattr(search_result, 'content') or not search_result.content:
                keyword = random.choice(hot_keywords)
                search_result = self.client.search_site(keyword, page=1)
                if not search_result or not hasattr(search_result, 'content') or not search_result.content:
                    return None

            ids = []
            for item in search_result.content:
                album_id = None
                # 方法1：正则提取（兼容性最强）
                item_str = str(item)
                match = re.search(r"'id'[:\s]*['\"]?(\d+)['\"]?", item_str)
                if match:
                    album_id = match.group(1)
                # 方法2：字典访问
                if not album_id and isinstance(item, dict):
                    album_id = item.get('id') or item.get('album_id') or item.get('aid')
                # 方法3：namedtuple 转换
                if not album_id and hasattr(item, '_asdict'):
                    d = item._asdict()
                    album_id = d.get('id') or d.get('album_id') or d.get('aid')
                # 方法4：对象属性
                if not album_id:
                    album_id = getattr(item, 'id', None) or getattr(item, 'album_id', None) or getattr(item, 'aid', None)
                if album_id:
                    ids.append(str(album_id))

            if not ids:
                return None

            chosen_id = random.choice(ids)
            return self.get_album_detail(chosen_id)
        except Exception as e:
            logger.error(f"随机推荐失败: {e}")
            return None

    # ---------- 下载与压缩加密 ----------
    def generate_password(self, length: int = 8) -> str:
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))

    def compress_folder_with_password(self, folder_path: str, output_zip: str, password: str) -> bool:
        try:
            with pyzipper.AESZipFile(
                output_zip, 'w',
                compression=pyzipper.ZIP_DEFLATED,
                encryption=pyzipper.WZ_AES
            ) as zf:
                zf.setpassword(password.encode('utf-8'))
                for root, dirs, files in os.walk(folder_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, start=os.path.dirname(folder_path))
                        zf.write(file_path, arcname)
            logger.info(f"压缩完成：{output_zip}")
            return True
        except Exception as e:
            logger.error(f"压缩文件夹失败: {e}")
            return False

    def download_album(self, album_id: str, enable_zip: bool = True) -> Tuple[bool, Optional[str], Optional[str]]:
        if not self.client:
            return False, None, None
        try:
            jmcomic.download_album(album_id, option=self.option)
            logger.info(f"下载漫画 {album_id} 完成，保存至 {self.download_dir}")

            album_folder = os.path.join(self.download_dir, album_id)
            if not os.path.isdir(album_folder):
                logger.error(f"下载目录不存在: {album_folder}")
                return False, None, None

            if not enable_zip:
                return True, None, album_folder

            password = self.generate_password(length=8)
            zip_path = os.path.join(self.download_dir, f"{album_id}.zip")
            success = self.compress_folder_with_password(album_folder, zip_path, password)

            if success:
                return True, password, zip_path
            else:
                return False, None, None
        except Exception as e:
            logger.error(f"下载漫画 {album_id} 失败: {e}")
            return False, None, None

    # ---------- 格式化 ----------
    def _format_album_detail(self, album) -> Dict[str, Any]:
        if isinstance(album, tuple):
            album = album[0]
        if album is None:
            return {}
        tags = getattr(album, 'tags', [])
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(',') if t.strip()]
        cover_url = self._get_cover_url(album)
        return {
            "id": album.id,
            "name": album.name,
            "author": getattr(album, 'author', '未知'),
            "page_count": getattr(album, 'page_count', 0),
            "likes": getattr(album, 'likes', 0),
            "views": getattr(album, 'views', 0),
            "description": getattr(album, 'description', '暂无简介'),
            "tags": tags,
            "cover_url": cover_url,
            "url": f"https://18comic.vip/album/{album.id}.html"
        }

    def _get_cover_url(self, album) -> Optional[str]:
        if hasattr(album, 'image_list') and album.image_list:
            return album.image_list[0].img_url
        if hasattr(album, 'cover') and album.cover:
            return album.cover
        if hasattr(album, 'img_url'):
            return album.img_url
        return None


_helper: Optional[JMComicHelper] = None

def get_helper(config: dict = None) -> Optional[JMComicHelper]:
    global _helper
    if _helper is None and config:
        _helper = JMComicHelper(
            proxy=config.get("proxy", ""),
            download_dir=config.get("download_dir", "./downloads/jmcomic")
        )
    return _helper